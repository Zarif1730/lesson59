package com.example.lesson59;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson59Application {

    public static void main(String[] args) {
        SpringApplication.run(Lesson59Application.class, args);
    }

}
