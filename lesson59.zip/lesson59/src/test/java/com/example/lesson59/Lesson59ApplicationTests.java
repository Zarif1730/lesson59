package com.example.lesson59;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson59ApplicationTests {

    @Test
    void contextLoads() {
    }

}
